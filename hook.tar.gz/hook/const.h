/*
 * const.h
 *
 *  Created on: 13/08/2015
 *      Author: miaohong(miaohong01@baidu.com)
 */

#ifndef CONST_H
#define CONST_H

#define PHP_APM_VERSION "0.0.1"
#define PHP_APM_NAME    "apm"
#define PHP_APM_AUTHOR  "APM Team"

#define FILE_RECORD_STATS "/tmp/.apm_file_record_stats"

#define FILE_RECORD_EVENTS "/tmp/.apm_file_record_events"

#define FILE_RECORD_TRACE "/tmp/.apm_file_record_trace"

#endif