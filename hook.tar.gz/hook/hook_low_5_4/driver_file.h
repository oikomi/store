/*
 * driver_file.h
 *
 *  Created on: 13/08/2015
 *      Author: miaohong(miaohong01@baidu.com)
 */

#ifndef DRIVER_FILE_H
#define DRIVER_FILE_H

#include "php_apm.h"


apm_driver_entry * apm_driver_file_create();

PHP_INI_MH(OnUpdateAPMfileErrorReporting);

#endif