/*
 * driver_socket.h
 *
 *  Created on: 13/08/2015
 *      Author: miaohong(miaohong01@baidu.com)
 */

#ifndef DRIVER_SOCKET_H
#define DRIVER_SOCKET_H

#include "zend_API.h"

#define APM_E_socket APM_E_ALL

//#define MAX_SOCKETS 10

#define MAX_SOCKETS 1

apm_driver_entry * apm_driver_socket_create();

PHP_INI_MH(OnUpdateAPMsocketErrorReporting);

#endif
